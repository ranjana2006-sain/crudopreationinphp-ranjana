<?php
$con=new mysqli('localhost','root','','project');

if($con){
    echo "Connection successfully"."<br>";
}else{
       die(mysqli_error($con));
}



?>